<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EduneedController extends Controller
{
}
