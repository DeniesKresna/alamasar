<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="<?php echo e(asset('appimages/student/'.$student->photo)); ?>" alt="User profile picture">

              <h3 class="profile-username text-center"><?php echo e($student->name); ?></h3>

              <p class="text-muted text-center">ID Code - <?php echo e($student->student_numb); ?></p>
              <p class="text-muted text-center">Status - <?php if($student->status == 'current'): ?> Current <?php elseif($student->status=='lulus'): ?> Lulus <?php elseif($student->status=='dropout'): ?> Drop Out <?php endif; ?></p>
              <?php if($student->status_desc != ''): ?><p class="text-muted text-center"><?php echo e($student->status_desc); ?></p><?php endif; ?>
              <!--
              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Followers</b> <a class="pull-right">1,322</a>
                </li>
                <li class="list-group-item">
                  <b>Following</b> <a class="pull-right">543</a>
                </li>
                <li class="list-group-item">
                  <b>Friends</b> <a class="pull-right">13,287</a>
                </li>
              </ul>
				-->
              <a href="<?php echo e(route('student.edit',['id'=>$student->id])); ?>" class="btn btn-primary btn-block"><b>Edit Siswa</b></a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          <!-- About Me Box -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Tentang Siswa</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <strong><i class="fa fa-book margin-r-5"></i> Pendidikan Terakhir</strong>

              <p class="text-muted">
                Gelar : <?php echo e($student->education->education); ?>

              </p>
              <p class="text-muted">
              	<?php echo e($student->education_desc); ?>

              </p>

              <hr>

              <strong><i class="fa fa-map-marker margin-r-5"></i> Alamat Siswa</strong>

              <p class="text-muted"><?php echo e($student->domicile); ?></p>

              <hr>

              <strong><i class="fa fa-phone margin-r-5"></i> Telepon</strong>

              <p class="text-muted"><?php echo e($student->contact); ?></p>

              <hr>

              <strong><i class="fa fa-envelope margin-r-5"></i> Email</strong>

              <p class="text-muted"><?php echo e($student->email); ?></p>

              <hr>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#activity" data-toggle="tab">Biodata Siswa</a></li>
              <li><a href="#timeline" data-toggle="tab">Keluarga</a></li>
              <li><a href="#settings" data-toggle="tab">Pendidikan</a></li>
              <li><a href="#donates" data-toggle="tab">Donasi</a></li>
            </ul>
            <div class="tab-content">
              <div class="active tab-pane" id="activity">
                <form class="form-horizontal">
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Kartu ID</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" readonly placeholder="-" value="<?php echo e($student->card->card); ?> - <?php echo e($student->id_numb); ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail" class="col-sm-2 control-label">Jenis Kelamin</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" readonly placeholder="-" value="<?php if($student->sex == 'L'): ?> Laki-laki <?php else: ?> Perempuan <?php endif; ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Alamat Sesuai Kartu ID</label>

                    <div class="col-sm-10">
                      <textarea class="form-control" readonly placeholder="-" rows="3"><?php echo e($student->address); ?></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputExperience" class="col-sm-2 control-label">Tempat, Tanggal Lahir</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" readonly placeholder="-" value="<?php echo e($student->birth_place); ?>, <?php echo date('d-m-Y',strtotime($student->birth_date)); ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputSkills" class="col-sm-2 control-label">Agama</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" readonly placeholder="-" value="<?php echo e($student->religion->religion); ?>">
                    </div>
                  </div>           
                  <div class="form-group">
                    <label for="inputSkills" class="col-sm-2 control-label">BANK</label>

                    <div class="col-sm-10">
                      <textarea type="text" class="form-control" readonly placeholder="-"><?php echo e($student->bank_name); ?> Cabang <?php echo e($student->bank_branch); ?>, <?php echo e($student->bank_city); ?>. No. Rek: <?php echo e($student->account_numb); ?></textarea>
                    </div>
                  </div>         
                  <div class="form-group">
                    <label for="inputSkills" class="col-sm-2 control-label">Catatan Khusus</label>

                    <div class="col-sm-10">
                      <textarea type="text" class="form-control" readonly placeholder="-"><?php echo e($student->note); ?></textarea>
                    </div>
                  </div>
                </form>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="timeline">
              	<div class="text-center"><h3> Anggota Keluarga</h3></div>
              	<div class="text-center"><small>No KK. <?php echo e($student->cc_numb); ?></small></div>
                 <form class="form-horizontal">
                  <div class="row">
                  	<?php $__currentLoopData = $student->families; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  	<div class="col-sm-6">
						          <span class="text-center"><h4><?php echo e($family->type); ?></h4></span>                  			
                  	  <div class="row">
  		                  <div class="form-group">
  		                    <label for="inputName" class="control-label col-sm-3">NIK</label>
  		                    <div class="col-sm-8">
  		                      <input type="text" class="form-control" readonly placeholder="-" value="<?php echo e($family->nik); ?>">
  		                    </div>
  		                  </div>
		                  </div>
                      <div class="row">
  		                  <div class="form-group">
  		                    <label for="inputName" class="control-label col-sm-3">Nama</label>
  		                    <div class="col-sm-8">
  		                      <input type="text" class="form-control" readonly placeholder="-" value="<?php echo e($family->name); ?>">
  		                    </div>
  		                  </div>
		                  </div>
                      <div class="row">
  		                  <div class="form-group">
  		                    <label for="inputName" class="control-label col-sm-3">Alamat</label>
  		                    <div class="col-sm-8">
  		                      <textarea rows="3" class="form-control" readonly placeholder="-"><?php echo e($family->address); ?></textarea>
  		                    </div>
  		                  </div>
		                  </div>
                      <div class="row">
  		                  <div class="form-group">
  		                    <label for="inputName" class="control-label col-sm-3">Tempat Lahir</label>
  		                    <div class="col-sm-8">
  		                      <input type="text" class="form-control" readonly placeholder="-" value="<?php echo e($family->birth_place); ?>">
  		                    </div>
  		                  </div>
		                  </div>
                      <div class="row">
  		                  <div class="form-group">
  		                    <label for="inputName" class="control-label col-sm-3">Tanggal Lahir</label>
  		                    <div class="col-sm-8">
  		                      <input type="text" class="form-control" readonly placeholder="-" value="<?php echo date('d-m-Y', strtotime($family->birth_date)) ?>">
  		                    </div>
  		                  </div>
		                  </div>
                      <div class="row">
  		                  <div class="form-group">
  		                    <label for="inputName" class="control-label col-sm-3">Telepon</label>
  		                    <div class="col-sm-8">
  		                      <input type="text" class="form-control" readonly placeholder="-" value="<?php echo e($family->contact); ?>">
  		                    </div>
  		                  </div>
		                  </div>
                      <div class="row">
  		                  <div class="form-group">
  		                    <label for="inputName" class="control-label col-sm-3">Agama</label>
  		                    <div class="col-sm-8">
  		                      <input type="text" class="form-control" readonly placeholder="-" value="<?php echo e($family->religion); ?>">
  		                    </div>
  		                  </div>
  		                </div>
                      <div class="row">
  		                  <div class="form-group">
  		                    <label for="inputName" class="control-label col-sm-3">Pekerjaan</label>
  		                    <div class="col-sm-8">
  		                      <input type="text" class="form-control" readonly placeholder="-" value="<?php echo e($family->occupation); ?>">
  		                    </div>
  		                  </div>
		                  </div>
                      <div class="row">
  		                  <div class="form-group">
  		                    <label for="inputName" class="control-label col-sm-3">Pendidikan</label>
  		                    <div class="col-sm-8">
  		                      <input type="text" class="form-control" readonly placeholder="-" value="<?php echo e($family->education); ?>">
  		                    </div>
  		                  </div>
		                  </div>
                      <div class="row">
  		                  <div class="form-group">
  		                    <label for="inputName" class="control-label col-sm-3">Status</label>
  		                    <div class="col-sm-8">
  		                      <input type="text" class="form-control" readonly placeholder="-" value="<?php echo e($family->marital_status); ?>">
  		                    </div>
  		                  </div>
		                  </div>
                      <div class="row">
  		                  <div class="form-group">
  		                    <label for="inputName" class="control-label col-sm-3">Meninggal?</label>
  		                    <div class="col-sm-8">
  		                      <input type="text" class="form-control" readonly placeholder="-" value="<?php if($family->isDied > 0): ?> Meninggal <?php else: ?> Masih Hidup <?php endif; ?>">
  		                    </div>
  		                  </div>
	                  </div>
	                </div>
	                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                 </form>
              </div>
              <!-- /.tab-pane -->

              <div class="tab-pane" id="settings">
                <h3> Daftar Nilai Siswa</h3>
                  <?php if(count($student->scores)>0): ?>
                        <?php $i=0; ?>
                         <table class="table table-bordered">
                            <thead>
                                <tr>
                                  <th>No</th>
                                  <th>Tahun Ajaran</th>
                                  <th>Jenis</th>
                                  <th>Nilai</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $student->scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $i++; ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($score->year); ?></td>
                                    <td><?php if($score->type == 'nb'): ?> Nilai Biasa <?php else: ?> Indeks Prestasi <?php endif; ?></td>
                                    <td><?php echo e($score->score); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                         </table>
                        <?php else: ?>
                          Belum ada data nilai
                        <?php endif; ?>
                        <hr>
                        <h3> Daftar Kebutuhan Pendidikan</h3>
                       <?php if(count($student->eduNeeds)>0): ?>
                        <?php $i=0; $total=0; ?>
                         <table class="table table-bordered">
                            <thead>
                                <tr>
                                  <th>No</th>
                                  <th>Kebutuhan</th>
                                  <th>Harga</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $student->eduNeeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eduNeed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $i++; $total = $total + $eduNeed->price ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($eduNeed->eduNeed); ?></td>
                                    <td>Rp. <?php echo e($eduNeed->price); ?> ,-</td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td colspan="2" class="text-center">Total Kebutuhan</td>
                                  <td>Rp. <?php echo e($total); ?> ,-</td>
                                </tr>
                            </tbody>
                         </table>
                        <?php else: ?>
                          Belum ada data kebutuhan pendidikan
                        <?php endif; ?>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="donates">
                <h3> History Donasi</h3>
                  <?php if(count($student->donates)>0): ?>
                        <?php $i=0; ?>
                         <table class="table table-bordered">
                            <thead>
                                <tr>
                                  <th>No</th>
                                  <th>Donatur</th>
                                  <th>Koordinator</th>
                                  <th>Tahun Ajaran</th>
                                  <th>Nominal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $student->donates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $i++; ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($donate->sponsor->name); ?></td>
                                    <td><?php echo e($donate->coordinator->name); ?></td>
                                    <td><ul><?php $__currentLoopData = $donate->years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($year->year); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </td>
                                    <td>Rp. <?php echo e($donate->amount); ?> ,-</td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                         </table>
                        <?php else: ?>
                          Belum ada data nilai
                        <?php endif; ?>
              </div>
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>