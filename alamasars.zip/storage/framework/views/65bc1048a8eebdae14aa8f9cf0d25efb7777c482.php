<table>
    <thead>
    <tr>
        <th>#</th>
        <th>Koordinator</th>
        <th>Sponsor</th>
        <th>Siswa</th>
        <th>Tahun Ajaran</th>
        <th>Jumlah</th>
        <th>Waktu Donasi</th>
        <th>Pengedit Terakhir</th>
        <th>Waktu Edit</th>
    </tr>
    </thead>
    <tbody>
    <?php $i=0; ?>
    <?php $__currentLoopData = $donates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $i++; ?>
        <tr>
            <td><?php echo e($i); ?></td>
            <td><?php echo e($donate->coordinator->name); ?></td>
            <td><?php echo e($donate->sponsor->name); ?></td>
            <td><?php echo e($donate->student->name); ?></td>
            <td><ul><?php $__currentLoopData = $donate->years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <li><?php echo e($year->year); ?>;</li>  
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></td>
            <td><?php echo e($donate->amount); ?></td>
            <td><?php echo e($donate->send_time); ?></td>
            <td><?php echo e($donate->pengupdate->name); ?></td>
            <td><?php echo e($donate->updated_at); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>